using System;
using Xamarin.Forms;
using Cringasu_Mihai_Razvan_Lab9.Models;

namespace Cringasu_Mihai_Razvan_Lab9.Views
{
    public partial class ListPage : ContentPage
    {
        public ListPage()
        {
            InitializeComponent();
        }

        async void OnSaveButtonClicked(object sender, EventArgs e)
        {
            var shopList = (ShopList)BindingContext;
            await App.Database.SaveShopListAsync(shopList);
        }

        async void OnDeleteButtonClicked(object sender, EventArgs e)
        {
            var shopList = (ShopList)BindingContext;
            await App.Database.DeleteShopListAsync(shopList);
        }

        async void OnDeleteItemClicked(object sender, EventArgs e)
        {
            var product = listView.SelectedItem as Product;
            if (product != null)
            {
                await App.Database.DeleteProductAsync(product);
                listView.ItemsSource = await App.Database.GetListProductsAsync(((ShopList)BindingContext).ID);
            }
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            var shopList = (ShopList)BindingContext;
            listView.ItemsSource = await App.Database.GetListProductsAsync(shopList.ID);
        }
    }
}